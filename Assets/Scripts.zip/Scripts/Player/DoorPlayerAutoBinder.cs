using UnityEngine;
using SojaExiles;

public class DoorPlayerAutoBinder : MonoBehaviour
{
    [Header("�ڵ����� ã�� �÷��̾� �±�")]
    [SerializeField] private string playerTag = "Player";

    private void Awake()
    {
        GameObject playerObject =
            GameObject.FindGameObjectWithTag(playerTag);

        if (playerObject == null)
        {
            Debug.LogError(
                "DoorPlayerAutoBinder: Player �±װ� ���� ������Ʈ�� ã�� ���߽��ϴ�."
            );

            return;
        }

        Transform playerTransform = playerObject.transform;

        BindNormalDoors(playerTransform);
        BindDoor1s(playerTransform);
        BindStallDoors(playerTransform);
    }

    private void BindNormalDoors(Transform playerTransform)
    {
        opencloseDoor[] doors =
            FindObjectsByType<opencloseDoor>(
                FindObjectsInactive.Include,
                FindObjectsSortMode.None
            );

        foreach (opencloseDoor door in doors)
        {
            door.Player = playerTransform;
        }

        Debug.Log($"�Ϲ� �� {doors.Length}�� �÷��̾� ���� �Ϸ�");
    }

    private void BindDoor1s(Transform playerTransform)
    {
        opencloseDoor1[] doors =
            FindObjectsByType<opencloseDoor1>(
                FindObjectsInactive.Include,
                FindObjectsSortMode.None
            );

        foreach (opencloseDoor1 door in doors)
        {
            door.Player = playerTransform;
        }

        Debug.Log($"Door1 �� {doors.Length}�� �÷��̾� ���� �Ϸ�");
    }

    private void BindStallDoors(Transform playerTransform)
    {
        opencloseStallDoor[] doors =
            FindObjectsByType<opencloseStallDoor>(
                FindObjectsInactive.Include,
                FindObjectsSortMode.None
            );

        foreach (opencloseStallDoor door in doors)
        {
            door.Player = playerTransform;
        }

        Debug.Log($"ȭ��� �� {doors.Length}�� �÷��̾� ���� �Ϸ�");
    }
}