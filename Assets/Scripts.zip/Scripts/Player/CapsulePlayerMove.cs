using UnityEngine;
using UnityEngine.EventSystems;

[RequireComponent(typeof(CharacterController))]
public class CapsulePlayerMove : MonoBehaviour
{
    [Header("�̵�")]
    [SerializeField] private float moveSpeed = 4f;
    [SerializeField] private float gravity = -20f;

    [Header("ī�޶�")]
    [SerializeField] private Transform cameraTransform;
    [SerializeField] private float mouseSensitivity = 2f;
    [SerializeField] private float maxLookAngle = 80f;

    private CharacterController characterController;

    private float verticalVelocity;
    private float cameraPitch;

    // true�� ���� 1��Ī ���� ��
    private bool firstPersonControlEnabled = true;

    // true�� �ɹ� UI � ���� ������ ������ ��� ����
    private bool externalControlLocked = false;

    private void Awake()
    {
        characterController =
            GetComponent<CharacterController>();
    }

    private void Start()
    {
        EnterFirstPersonMode();
    }

    private void Update()
    {
        // �ɹ� ���� �ƴ� ����
        // ESC�� ���콺 Ŭ������ Ŀ�� ��带 ������ �� ����
        if (!externalControlLocked)
        {
            HandleCursorMode();
        }

        if (!firstPersonControlEnabled)
        {
            return;
        }

        Move();
        Look();
    }

    private void Move()
    {
        float horizontal =
            Input.GetAxisRaw("Horizontal");

        float vertical =
            Input.GetAxisRaw("Vertical");

        Vector3 moveDirection =
            transform.right * horizontal +
            transform.forward * vertical;

        moveDirection =
            Vector3.ClampMagnitude(
                moveDirection,
                1f
            );

        if (characterController.isGrounded &&
            verticalVelocity < 0f)
        {
            verticalVelocity = -2f;
        }

        verticalVelocity +=
            gravity * Time.deltaTime;

        Vector3 finalMovement =
            moveDirection * moveSpeed;

        finalMovement.y =
            verticalVelocity;

        characterController.Move(
            finalMovement * Time.deltaTime
        );
    }

    private void Look()
    {
        float mouseX =
            Input.GetAxis("Mouse X") *
            mouseSensitivity;

        float mouseY =
            Input.GetAxis("Mouse Y") *
            mouseSensitivity;

        transform.Rotate(
            Vector3.up * mouseX
        );

        cameraPitch -= mouseY;

        cameraPitch = Mathf.Clamp(
            cameraPitch,
            -maxLookAngle,
            maxLookAngle
        );

        if (cameraTransform != null)
        {
            cameraTransform.localRotation =
                Quaternion.Euler(
                    cameraPitch,
                    0f,
                    0f
                );
        }
    }

    private void HandleCursorMode()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            ExitFirstPersonMode();
            return;
        }

        // Ŀ���� Ǯ�� ���¿��� ���� Ŭ�� ��
        if (!firstPersonControlEnabled &&
            Input.GetMouseButtonDown(0))
        {
            bool pointerOverUI =
                EventSystem.current != null &&
                EventSystem.current
                    .IsPointerOverGameObject();

            // UI ���� Ŭ���ߴٸ�
            // 1��Ī ���� ���ư��� ����
            if (pointerOverUI)
            {
                return;
            }

            EnterFirstPersonMode();
        }
    }

    private void EnterFirstPersonMode()
    {
        // �ɹ� ������ ��� ���¶��
        // 1��Ī ���� ���ư��� ����
        if (externalControlLocked)
        {
            return;
        }

        firstPersonControlEnabled = true;

        Cursor.visible = false;
        Cursor.lockState =
            CursorLockMode.Locked;

        if (CursorController.Instance != null)
        {
            CursorController.Instance
                .HideCustomCursor();
        }
    }

    private void ExitFirstPersonMode()
    {
        firstPersonControlEnabled = false;

        Cursor.lockState =
            CursorLockMode.None;

        Cursor.visible = false;

        if (CursorController.Instance != null)
        {
            CursorController.Instance
                .ShowCustomCursor();
        }
    }

    // �ɹ� UI�� �� �� ȣ��
    public void DisablePlayerControl()
    {
        externalControlLocked = true;
        firstPersonControlEnabled = false;

        Cursor.lockState =
            CursorLockMode.None;

        Cursor.visible = false;

        if (CursorController.Instance != null)
        {
            CursorController.Instance
                .ShowCustomCursor();
        }
    }

    // �ɹ� UI�� ���� �� ȣ��
    public void EnablePlayerControl()
    {
        externalControlLocked = false;

        EnterFirstPersonMode();
    }

    private void OnDisable()
    {
        Cursor.lockState =
            CursorLockMode.None;

        Cursor.visible = false;

        if (CursorController.Instance != null)
        {
            CursorController.Instance
                .ShowCustomCursor();
        }
    }
}