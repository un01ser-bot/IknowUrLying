using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(
    fileName = "EvidenceDatabase",
    menuName = "Detective Game/Evidence Database"
)]
public class EvidenceDatabase : ScriptableObject
{
    [Header("���ӿ� �����ϴ� ��� ����")]
    public List<EvidenceData> allEvidence = new List<EvidenceData>();

    private Dictionary<string, EvidenceData> evidenceDictionary;

    private void OnEnable()
    {
        BuildDictionary();
    }

    public void BuildDictionary()
    {
        evidenceDictionary = new Dictionary<string, EvidenceData>();

        foreach (EvidenceData evidence in allEvidence)
        {
            if (evidence == null)
            {
                continue;
            }

            if (string.IsNullOrWhiteSpace(evidence.evidenceId))
            {
                Debug.LogWarning(
                    $"���� '{evidence.name}'�� Evidence ID�� �����ϴ�."
                );

                continue;
            }

            if (evidenceDictionary.ContainsKey(evidence.evidenceId))
            {
                Debug.LogError(
                    $"�ߺ��� Evidence ID�� �ֽ��ϴ�: {evidence.evidenceId}"
                );

                continue;
            }

            evidenceDictionary.Add(evidence.evidenceId, evidence);
        }
    }

    public EvidenceData GetEvidence(string evidenceId)
    {
        if (evidenceDictionary == null)
        {
            BuildDictionary();
        }

        evidenceDictionary.TryGetValue(evidenceId, out EvidenceData evidence);
        return evidence;
    }
}