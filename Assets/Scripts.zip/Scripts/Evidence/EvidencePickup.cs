using UnityEngine;

public class EvidencePickup : MonoBehaviour
{
    [Header("�� ������Ʈ�� ���� ����")]
    [SerializeField] private EvidenceData evidenceData;

    [Header("�÷��̾� �Ÿ� ����")]
    [SerializeField] private float interactionDistance = 5f;

    [Header("���� �� ó��")]
    [SerializeField] private bool hideAfterCollect = true;

    private Transform player;
    private bool isCollected;

    private void Start()
    {
        FindPlayer();

        if (EvidenceInventory.Instance != null &&
            evidenceData != null &&
            EvidenceInventory.Instance.HasEvidence(
                evidenceData.evidenceId
            ))
        {
            ApplyCollectedState();
        }
    }

    private void FindPlayer()
    {
        GameObject playerObject =
            GameObject.FindGameObjectWithTag("Player");

        if (playerObject != null)
        {
            player = playerObject.transform;
        }
        else
        {
            Debug.LogWarning(
                $"Player �±� ������Ʈ�� ã�� ���߽��ϴ�: {name}"
            );
        }
    }

    private void OnMouseOver()
    {
        if (isCollected)
        {
            return;
        }

        if (player == null)
        {
            FindPlayer();

            if (player == null)
            {
                return;
            }
        }

        float distance = Vector3.Distance(
            player.position,
            transform.position
        );

        if (distance > interactionDistance)
        {
            return;
        }

        if (Input.GetMouseButtonDown(0))
        {
            TryCollect();
        }
    }

    public virtual void TryCollect()
    {
        if (EvidenceInventory.Instance == null)
        {
            Debug.LogError(
                "���� EvidenceInventory�� �����ϴ�."
            );

            return;
        }

        if (evidenceData == null)
        {
            Debug.LogError(
                $"EvidenceData�� ������� �ʾҽ��ϴ�: {name}"
            );

            return;
        }

        bool collected =
            EvidenceInventory.Instance.CollectEvidence(evidenceData);

        if (collected)
        {
            ApplyCollectedState();
        }
    }

    protected virtual void ApplyCollectedState()
    {
        isCollected = true;

        if (hideAfterCollect)
        {
            gameObject.SetActive(false);
        }
    }
}