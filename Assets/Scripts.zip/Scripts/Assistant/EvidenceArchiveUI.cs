using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EvidenceArchiveUI : MonoBehaviour
{
    [Header("���� ���")]
    [SerializeField] private Transform contentParent;
    [SerializeField] private EvidenceListItemUI evidenceItemPrefab;

    [Header("���� �� ����")]
    [SerializeField] private EvidenceDetailUI evidenceDetailUI;

    [Header("��� ����")]
    [SerializeField] private bool selectFirstEvidenceAutomatically = true;

    private readonly List<GameObject> spawnedItems =
        new List<GameObject>();

    private Coroutine refreshCoroutine;

    private void OnEnable()
    {
        refreshCoroutine = StartCoroutine(RefreshNextFrame());
    }

    private void OnDisable()
    {
        if (refreshCoroutine != null)
        {
            StopCoroutine(refreshCoroutine);
            refreshCoroutine = null;
        }
    }

    private IEnumerator RefreshNextFrame()
    {
        // EvidenceInventory�� Awake�� ���� ����� �ð��� ��
        yield return null;

        Refresh();
        refreshCoroutine = null;
    }

    public void Refresh()
    {
        ClearList();

        if (EvidenceInventory.Instance == null)
        {
            Debug.LogWarning(
                "EvidenceInventory�� �����ϴ�. " +
                "������ ���� EvidenceSystem ������Ʈ�� " +
                "EvidenceInventory ������Ʈ�� �ִ��� Ȯ���ϼ���."
            );

            return;
        }

        if (contentParent == null)
        {
            Debug.LogError(
                "EvidenceArchiveUI�� Content Parent�� ��� �ֽ��ϴ�."
            );

            return;
        }

        if (evidenceItemPrefab == null)
        {
            Debug.LogError(
                "EvidenceArchiveUI�� Evidence Item Prefab�� ��� �ֽ��ϴ�."
            );

            return;
        }

        List<EvidenceData> collectedEvidence =
            EvidenceInventory.Instance.GetCollectedEvidence();

        foreach (EvidenceData evidence in collectedEvidence)
        {
            EvidenceListItemUI item = Instantiate(
                evidenceItemPrefab,
                contentParent
            );

            item.Setup(evidence, SelectEvidence);
            spawnedItems.Add(item.gameObject);
        }

        if (selectFirstEvidenceAutomatically &&
            collectedEvidence.Count > 0)
        {
            SelectEvidence(collectedEvidence[0]);
        }
        else if (evidenceDetailUI != null)
        {
            evidenceDetailUI.Clear();
        }

        Debug.Log(
            $"������ ���� ��� ���� �Ϸ�: {collectedEvidence.Count}��"
        );
    }

    private void SelectEvidence(EvidenceData evidence)
    {
        if (evidenceDetailUI == null)
        {
            Debug.LogWarning(
                "Evidence Detail UI�� ������� �ʾҽ��ϴ�."
            );

            return;
        }

        evidenceDetailUI.ShowEvidence(evidence);
    }

    private void ClearList()
    {
        foreach (GameObject item in spawnedItems)
        {
            if (item != null)
            {
                Destroy(item);
            }
        }

        spawnedItems.Clear();
    }
}