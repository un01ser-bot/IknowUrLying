using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class AssistantDialogueController : MonoBehaviour
{
    [Header("��ȭ UI")]
    [SerializeField] private GameObject dialoguePanel;
    [SerializeField] private TMP_Text dialogueText;

    [Header("������")]
    [SerializeField] private GameObject choicePanel;
    [SerializeField] private Button noteButton;
    [SerializeField] private Button hintButton;
    [SerializeField] private Button cancelButton;

    [Header("���")]
    [SerializeField]
    private string enterDialogue =
        "Ž����, ���̾��?";

    [SerializeField]
    private string clickedDialogue =
        "�� ���͵帱���?";

    [Header("���� �� �ӽ� ���")]
    [SerializeField]
    private string noteDialogue =
        "�����ص� ���� ��Ʈ�� �����帱�Կ�.";

    [SerializeField]
    private string hintDialogue =
        "������ ���캸�� ������ ���� �����غ����?";

    [SerializeField]
    private string cancelDialogue =
        "�˰ھ��. �ʿ��ϸ� �ٽ� �ҷ��ּ���.";

    [Header("Ÿ�ڱ� ȿ��")]
    [SerializeField]
    private float typingSpeed = 0.04f;

    private Coroutine typingCoroutine;

    private void Start()
    {
        SetupButtons();

        if (dialoguePanel != null)
        {
            dialoguePanel.SetActive(true);
        }

        if (choicePanel != null)
        {
            choicePanel.SetActive(false);
        }

        TypeDialogue(enterDialogue);
    }

    private void SetupButtons()
    {
        if (noteButton != null)
        {
            noteButton.onClick.RemoveAllListeners();
            noteButton.onClick.AddListener(OnNoteSelected);
        }

        if (hintButton != null)
        {
            hintButton.onClick.RemoveAllListeners();
            hintButton.onClick.AddListener(OnHintSelected);
        }

        if (cancelButton != null)
        {
            cancelButton.onClick.RemoveAllListeners();
            cancelButton.onClick.AddListener(OnCancelSelected);
        }
    }

    public void OnAssistantClicked()
    {
        HideChoices();

        TypeDialogue(
            clickedDialogue,
            ShowChoices
        );
    }

    private void OnNoteSelected()
    {
        HideChoices();

        TypeDialogue(noteDialogue);

        Debug.Log("���� ��Ʈ ���� ����");
    }

    private void OnHintSelected()
    {
        HideChoices();

        TypeDialogue(hintDialogue);

        Debug.Log("��Ʈ �ޱ� ����");
    }

    private void OnCancelSelected()
    {
        HideChoices();

        TypeDialogue(cancelDialogue);
    }

    private void ShowChoices()
    {
        if (choicePanel != null)
        {
            choicePanel.SetActive(true);
        }
    }

    private void HideChoices()
    {
        if (choicePanel != null)
        {
            choicePanel.SetActive(false);
        }
    }

    private void TypeDialogue(
        string text,
        System.Action onComplete = null
    )
    {
        if (typingCoroutine != null)
        {
            StopCoroutine(typingCoroutine);
        }

        typingCoroutine =
            StartCoroutine(
                TypeDialogueCoroutine(
                    text,
                    onComplete
                )
            );
    }

    private IEnumerator TypeDialogueCoroutine(
        string text,
        System.Action onComplete
    )
    {
        if (dialogueText == null)
        {
            yield break;
        }

        dialogueText.text = "";

        foreach (char letter in text)
        {
            dialogueText.text += letter;

            yield return new WaitForSeconds(
                typingSpeed
            );
        }

        typingCoroutine = null;

        onComplete?.Invoke();
    }
}