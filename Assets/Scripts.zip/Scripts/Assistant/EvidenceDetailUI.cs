using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class EvidenceDetailUI : MonoBehaviour
{
    [Header("�� ���� UI")]
    [SerializeField] private Image evidenceImage;
    [SerializeField] private TMP_Text evidenceNameText;
    [SerializeField] private TMP_Text locationText;

    [SerializeField]
    private TMP_Text relatedSuspectText;

    [SerializeField] private TMP_Text descriptionText;

    [Header("���� �� �ȳ� ����")]
    [SerializeField]
    private string emptyNameText =
        "Ȯ���� ���Ÿ� �����ϼ���.";

    private void Start()
    {
        Clear();
    }

    public void ShowEvidence(EvidenceData evidence)
    {
        if (evidence == null)
        {
            Clear();
            return;
        }

        if (evidenceImage != null)
        {
            evidenceImage.sprite = evidence.evidenceImage;
            evidenceImage.enabled =
                evidence.evidenceImage != null;
        }

        if (evidenceNameText != null)
        {
            evidenceNameText.text = evidence.evidenceName;
        }

        if (locationText != null)
        {
            locationText.text =
                $"�߰� ���\n{evidence.discoveredLocation}";
        }

        if (relatedSuspectText != null)
        {
            relatedSuspectText.text =
                GetRelatedSuspectText(evidence);
        }

        if (descriptionText != null)
        {
            descriptionText.text = evidence.description;
        }
    }

    private string GetRelatedSuspectText(EvidenceData evidence)
    {
        if (evidence.relatedSuspects == null ||
            evidence.relatedSuspects.Count == 0)
        {
            return "���� ������\n����";
        }

        StringBuilder builder = new StringBuilder();

        builder.Append("���� ������\n");

        bool hasSuspect = false;

        foreach (SuspectProfile suspect in evidence.relatedSuspects)
        {
            if (suspect == null)
            {
                continue;
            }

            if (hasSuspect)
            {
                builder.Append(", ");
            }

            builder.Append(suspect.suspectName);

            hasSuspect = true;
        }

        if (!hasSuspect)
        {
            builder.Append("����");
        }

        return builder.ToString();
    }

    public void Clear()
    {
        if (evidenceImage != null)
        {
            evidenceImage.sprite = null;
            evidenceImage.enabled = false;
        }

        if (evidenceNameText != null)
        {
            evidenceNameText.text = emptyNameText;
        }

        if (locationText != null)
        {
            locationText.text = string.Empty;
        }

        if (relatedSuspectText != null)
        {
            relatedSuspectText.text = string.Empty;
        }

        if (descriptionText != null)
        {
            descriptionText.text = string.Empty;
        }
    }
}