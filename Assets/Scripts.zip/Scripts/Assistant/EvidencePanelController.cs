using UnityEngine;

public class EvidencePanelController : MonoBehaviour
{
    [Header("���� Ȯ�� �г�")]
    [SerializeField] private GameObject evidencePanel;

    private void Start()
    {
        if (evidencePanel != null)
        {
            evidencePanel.SetActive(false);
        }
    }

    public void OpenPanel()
    {
        if (evidencePanel == null)
        {
            Debug.LogWarning("Evidence Panel�� ������� �ʾҽ��ϴ�.");
            return;
        }

        evidencePanel.SetActive(true);
    }

    public void ClosePanel()
    {
        if (evidencePanel == null)
        {
            return;
        }

        evidencePanel.SetActive(false);
    }
}