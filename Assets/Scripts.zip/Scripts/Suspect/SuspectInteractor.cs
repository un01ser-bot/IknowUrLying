using UnityEngine;

public class SuspectInteractor : MonoBehaviour
{
    [Header("��ȣ�ۿ� ����")]
    [SerializeField] private Camera playerCamera;
    [SerializeField] private float interactionDistance = 3f;
    [SerializeField] private KeyCode interactionKey = KeyCode.E;

    [Header("�ɹ� UI")]
    [SerializeField] private SuspectChatUI suspectChatUI;

    private SuspectNPC currentSuspect;

    private void Update()
    {
        FindSuspect();

        if (currentSuspect != null &&
            Input.GetKeyDown(interactionKey))
        {
            InteractWithSuspect();
        }
    }

    private void FindSuspect()
    {
        currentSuspect = null;

        if (playerCamera == null)
        {
            return;
        }

        Ray ray = new Ray(
            playerCamera.transform.position,
            playerCamera.transform.forward
        );

        if (Physics.Raycast(
            ray,
            out RaycastHit hit,
            interactionDistance))
        {
            currentSuspect =
                hit.collider.GetComponentInParent<SuspectNPC>();
        }
    }

    private void InteractWithSuspect()
    {
        SuspectProfile profile =
            currentSuspect.Profile;

        if (profile == null)
        {
            Debug.LogWarning(
                "�� �����ڿ��� SuspectProfile�� �����ϴ�."
            );
            return;
        }

        if (suspectChatUI == null)
        {
            Debug.LogWarning(
                "SuspectChatUI�� ������� �ʾҽ��ϴ�."
            );
            return;
        }

        suspectChatUI.OpenChat(profile);
    }

    private void OnDrawGizmosSelected()
    {
        if (playerCamera == null)
        {
            return;
        }

        Gizmos.DrawRay(
            playerCamera.transform.position,
            playerCamera.transform.forward *
            interactionDistance
        );
    }
}